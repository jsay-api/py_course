# coding: utf-8
#!/usr/bin/python3

"""Лото

Правила игры в лото.

Игра ведется с помощью специальных карточек, на которых отмечены числа, 
и фишек (бочонков) с цифрами.

Количество бочонков — 90 штук (с цифрами от 1 до 90).

Каждая карточка содержит 3 строки по 9 клеток. В каждой строке по 5 случайных цифр, 
расположенных по возрастанию. Все цифры в карточке уникальны. Пример карточки:

--------------------------
    9 43 62          74 90
 2    27    75 78    82
   41 56 63     76      86 
--------------------------

В игре 2 игрока: пользователь и компьютер. Каждому в начале выдается 
случайная карточка. 

Каждый ход выбирается один случайный бочонок и выводится на экран.
Также выводятся карточка игрока и карточка компьютера.

Пользователю предлагается зачеркнуть цифру на карточке или продолжить.
Если игрок выбрал "зачеркнуть":
	Если цифра есть на карточке - она зачеркивается и игра продолжается.
	Если цифры на карточке нет - игрок проигрывает и игра завершается.
Если игрок выбрал "продолжить":
	Если цифра есть на карточке - игрок проигрывает и игра завершается.
	Если цифры на карточке нет - игра продолжается.
	
Побеждает тот, кто первый закроет все числа на своей карточке.

Пример одного хода:

Новый бочонок: 70 (осталось 76)
------ Ваша карточка -----
 6  7          49    57 58
   14 26     -    78    85
23 33    38    48    71   
--------------------------
-- Карточка компьютера ---
 7 87     - 14    11      
      16 49    55 88    77    
   15 20     -       76  -
--------------------------
Зачеркнуть цифру? (y/n)

Подсказка: каждый следующий случайный бочонок из мешка удобно получать 
с помощью функции-генератора.

Подсказка: для работы с псевдослучайными числами удобно использовать 
модуль random: http://docs.python.org/3/library/random.html

"""

from random import shuffle, randint

import sys
reload(sys)
sys.setdefaultencoding('cp866')


class LoserExcetion(Exception):
    def __init__(self, user):
        self.user = user
    
    def __str__(self):
        return u'Игрок {0} проиграл'.format(self.user)
        
    
class Barrel():
    ''' Бочонок (сумка с бочонками)
    '''
    def __init__(self, max_count):
        self.max_count = max_count
        self.items = [i for i in xrange(1, max_count+1)]
        shuffle(self.items)
    
    def __iter__(self):
        return self
    
    def next(self):
       
        if self.items:
            index = randint(0,len(self.items)-1)        
            return self.items.pop(index)
        else:
            raise StopIteration
    
    def __len__(self):
        return len(self.items)
                

class Card():
    ''' Карточка лото
    '''
    def __init__(self):
        self.numbers = [i for i in Barrel(90)]
        self.numbers = sorted(self.numbers[:5]) +  sorted(self.numbers[5:10]) + sorted(self.numbers[10:15])
        
        self.templates = []     # шаблоны вывода строк карточки
        self.gen_templates()    # генерируем шаблоны
    
    def strike(self, number):
        ''' Зачеркивание числа на карточке
        '''
        if number in self.numbers:
            index = self.numbers.index(number)
            self.numbers[index] = 'x'
            return True
        else:
            return False
            
    def gen_templates(self):
        ''' Создание шаблона вывода чисел
        '''
        for j in xrange(3):
            template = ['{0[%d]:>2}' % i for i in xrange(5)]
            for i in xrange(4):         # добавляем рандомные пробелы в шаблон
                it = randint(0,len(template))
                template.insert(it,'  ')
          
            template = ' '.join(template) 
            self.templates.append(template)

    def __str__(self):      
        line1 = self.templates[0].format(self.numbers[:5])    
        line2 = self.templates[1].format(self.numbers[5:10])    
        line3 = self.templates[2].format(self.numbers[10:15])    

        res = '\n'.join(('-'*30, line1, line2, line3))
        return res        
            
    def isfinished(self):
        if self.numbers.count('x') == 15:
            return True
        else:
            return False

    
class Gamer():
    ''' Игрок (пользователь/компьютер)
    '''
    def __init__(self, isrobot=True):
        self.card = Card()
        self.isrobot = isrobot
    
    def __str__(self):
        return u'Компьютер' if self.isrobot else u'Человек'
    
    def human_turn(self, number):
        ''' Ход человека
        '''
        while True:     # цикл получения ответа человека
            turn = raw_input(u'\n Зачеркнуть число? (y/n/q) ').lower()
            if turn == 'y':
                if self.card.strike(number):
                    print u'\nХорошо, Человек! Продолжаем...'    
                else:
                    raise LoserExcetion(u'Человек')
                break    
            elif turn == 'n':
                if number not in self.card.numbers:
                    print u'\nХорошо, Человек! Продолжаем...'    
                else:
                    raise LoserExcetion(u'Человек')                
                break    
            elif turn == 'q':
                print u'До свидания, Человек!'
                sys.exit(0)
    
            else:
                print u'Неверный вариант. Еще раз.'
            
    def robot_turn(self, number):
        ''' Ход робота
        '''
        if number in self.card.numbers:             # робот всегда знает, что ему зачеркивать :)
            self.card.strike(number)      
    
    def make_turn(self, number): 
        ''' Зачеркнуть цифру
        '''
        if self.isrobot:
            self.robot_turn(number)
        else:
            self.human_turn(number)
        
    def iswinner(self):
        if self.card.isfinished():
            return True
        else:
            return False

            
class Game():
    ''' Игра лото
    '''
    def __init__(self, *args):
        self.gamers = args
        self.finished = False
    
    def play(self):
        barrel = Barrel(90)
        while not self.finished:
            bar = next(barrel)          # берем новый бочонок из сумки
            print u'\n-> Новый бочонок: {0} (осталось {1})'.format(bar, len(barrel))

            for gamer in self.gamers:
                print '\n', gamer
                print gamer.card
            
            for gamer in self.gamers:
                try: 
                    gamer.make_turn(bar)
                except LoserExcetion as loser:
                    print u'{0} проиграл'.format(gamer)
                    self.finished = True
                    break
                    
                if gamer.iswinner():
                    print u'**** Победил {0}! ****'.format(gamer)
                    self.finished = True
                    break
                    
        print u'Игра окончена!'
        
        
def main():
    while True:
        resp = raw_input(u'\n Начать новую игру (y/n)? ')
        if resp.lower() == 'y':
            user = Gamer(False)
            robot = Gamer()
            
            game = Game(user, robot)
            game.play()
        else:
            break
    
    
if __name__ == '__main__':
    main()