# coding: utf-8
'''
# ----- Python 2.x -----------------
import codecs
f = codecs.open('song_python_866.txt', encoding='cp866')

# В Python 2.x у строк есть методы encode и decode
for line in f:
    # line = line.decode('cp866')         # <- декодируем строку, если использовали выше обычный open(), а не codecs.open()
    print line.encode('utf-8')            # <- кодируем строку в нужную кодировку (определяется консолью, файлом, требованиями)
'''
    
# ----- Python 3.x -----------------
f = open('song_python_866.txt', encoding='cp866')       #  после чтения из файла с указанием кодировки строки будут правильно интерпретированы

# В Python 3.x у строк (str) есть метод encode, но нет decode
# У байтовых строк (bytes) есть метод decode, но нет encode
for line in f:
    print (line)            # <- просто выводим строку
    # print (line.encode('cp1251').decode('cp866'))       # <- а вот так можно получить UnicodeEncodeError