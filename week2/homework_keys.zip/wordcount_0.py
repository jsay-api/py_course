#!/usr/bin/python3
# coding: utf-8

"""Упражнение "Количество слов"

Функция main() ниже уже определена и заполнена. Она вызывает функции 
print_words() и print_top(), которые вам нужно заполнить.

1. Если при вызове файла задан флаг --count, вызывается функция 
print_words(filename), которая подсчитывает, как часто каждое слово встречается 
в тексте и выводит:
слово1 количество1
слово2 количество2
...

Выводимый список отсортируйте в алфавитном порядке. Храните все слова 
в нижнем регистре, т.о. слова "Слон" и "слон" будут обрабатываться как одно 
слово.

2. Если задан флаг --topcount, вызывается функция print_top(filename),
которая аналогична функции print_words(), но выводит только топ-20 наиболее 
часто встречающихся слов, таким образом первым будет самое часто встречающееся 
слово, за ним следующее по частоте и т.д.

Используйте str.split() (без аргументов), чтобы разбить текст на слова.

Отсекайте знаки припинания при помощи str.strip() с знаками припинания 
в качестве аргумента.

Совет: не пишите всю программу сразу. Доведите ее до какого-то промежуточного 
состояния и выведите вашу текущую структуру данных. Когда все будет работать 
как надо, перейдите к следующему этапу.

Дополнительно: определите вспомогательную функцию, чтобы избежать дублирования 
кода внутри print_words() и print_top().

"""

import sys
import string

# +++ваш код+++
# Определите и заполните функции print_words(filename) и print_top(filename).
# Вы также можете написать вспомогательную функцию, которая читает файл,
# строит по нему словарь слово/количество и возвращает этот словарь.
# Затем print_words() и print_top() смогут просто вызывать эту вспомогательную функцию.

def get_words_count(filename):
    ''' Построение словаря, содержащего слова и их количество
    '''
    f = open(filename)
    words = f.read().split()        # читаем текст и разбиваем его на слова по пробелам
    words_count = {}                # результирующий словарь с количеством каждого слова
    
    delims = string.punctuation + ' '                           # знаки пунктуации и пробел
    for word in words:
        word = word.decode('utf-8').strip(delims).lower()
        if word:
            words_count[word] = words_count.get(word, 0) + 1    # используем get - если нет ключа мы его добавим со значением 0
                    
    return words_count

    
def print_top(filename):
    ''' Функция выводит 20 самых популярных слов
    '''
    words = get_words_count(filename)
    for word, count in sorted(words.items(), key = lambda x: x[1], reverse = True)[:20]:
        # указываем явно кодировку, чтобы в любимой консоли (Windows) все слова отобразились по-русски
        print '{0:10}\t{1:5}'.format(word.encode('cp866'), count)

        
def print_words(filename):
    ''' Функция выводит слова и их количество в переданном файле
    '''    
    words = get_words_count(filename)
    for word, count in sorted(words.items()):
        # указываем явно кодировку, чтобы в любимой консоли (Windows) все слова отобразились по-русски
        print '{0:10}\t{1:5}'.format(word.encode('cp866'), count)
        
###

# Это базовый код для разбора аргументов коммандной строки.
# Он вызывает print_words() и print_top(), которые необходимо определить.
def main():
    if len(sys.argv) != 3:
        print('usage: python wordcount.py {--count | --topcount} file')
        sys.exit(1)

    option = sys.argv[1]
    filename = sys.argv[2]
    if option == '--count':
        print_words(filename)
    elif option == '--topcount':
        print_top(filename)
    else:
        print('unknown option: ' + option)
    sys.exit(1)

if __name__ == '__main__':
    main()
